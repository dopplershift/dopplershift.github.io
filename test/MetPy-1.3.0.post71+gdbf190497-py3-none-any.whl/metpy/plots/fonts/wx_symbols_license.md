The wx_symbols.ttf font is modified from the OGC Meteorology and Oceanography Domain Working
Group World Weather Symbols repository.

https://github.com/OGCMetOceanDWG/WorldWeatherSymbols

Font is released under the Creative Commons Attribution 4.0 International (CC BY 4.0) license.

http://creativecommons.org/licenses/by/4.0